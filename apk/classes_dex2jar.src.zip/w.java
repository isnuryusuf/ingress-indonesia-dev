import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class w extends ClickListener
{
  w(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.z);
    for (boolean bool = true; ; bool = false)
    {
      J.z = bool;
      b.c(this.a.a);
      b.d(this.a.a).a.setText("Restart is recommended");
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     w
 * JD-Core Version:    0.6.2
 */