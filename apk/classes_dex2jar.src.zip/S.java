public enum S
{
  public final String a;

  static
  {
    jdField_a_of_type_S = new S("AT_END", 1, "Last");
    b = new S("AT_START", 2, "First");
    S[] arrayOfS = new S[3];
    arrayOfS[0] = c;
    arrayOfS[1] = jdField_a_of_type_S;
    arrayOfS[2] = b;
    jdField_a_of_type_ArrayOfS = arrayOfS;
  }

  private S(String arg3)
  {
    Object localObject;
    this.jdField_a_of_type_JavaLangString = localObject;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     S
 * JD-Core Version:    0.6.2
 */