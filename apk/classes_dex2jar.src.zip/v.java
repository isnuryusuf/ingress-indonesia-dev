import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class v extends ClickListener
{
  v(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.y);
    for (boolean bool = true; ; bool = false)
    {
      J.y = bool;
      b.c(this.a.a);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     v
 * JD-Core Version:    0.6.2
 */