import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.nianticproject.ingress.gameentity.f;

final class Q
{
  public final TextButton a;
  public f a;

  private Q(N paramN)
  {
    this.a = new TextButton("", N.a(paramN));
    this.a.addListener(new R(this));
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     Q
 * JD-Core Version:    0.6.2
 */