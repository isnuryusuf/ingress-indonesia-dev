import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class n extends ClickListener
{
  n(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.t);
    for (boolean bool = true; ; bool = false)
    {
      J.t = bool;
      b.c(this.a.a);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     n
 * JD-Core Version:    0.6.2
 */