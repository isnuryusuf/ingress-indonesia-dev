package a.a.a.a;

public abstract interface d<K>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.d
 * JD-Core Version:    0.6.2
 */