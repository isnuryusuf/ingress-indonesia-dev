package a.a.a.a.c;

import a.a.a.a.d;

public final class g
{
  public static final Object[] a = new Object[0];
  public static final d b = new h((byte)0);

  public static <K> void a(K[] paramArrayOfK)
  {
    int j;
    for (int i = paramArrayOfK.length; ; i = j)
    {
      j = i - 1;
      if (i == 0)
        break;
      paramArrayOfK[j] = null;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.g
 * JD-Core Version:    0.6.2
 */