package a.a.a.a.c;

public abstract class c<K>
  implements l<K>
{
  public void remove()
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.c
 * JD-Core Version:    0.6.2
 */