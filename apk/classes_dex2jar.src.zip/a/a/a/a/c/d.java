package a.a.a.a.c;

public abstract class d<K> extends a<K>
  implements o<K>
{
  public void add(K paramK)
  {
    throw new UnsupportedOperationException();
  }

  public void set(K paramK)
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.d
 * JD-Core Version:    0.6.2
 */