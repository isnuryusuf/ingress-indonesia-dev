package a.a.a.a.c;

import java.util.Collection;

public abstract interface j<K> extends k<K>, Collection<K>
{
  public abstract l<K> a();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.j
 * JD-Core Version:    0.6.2
 */