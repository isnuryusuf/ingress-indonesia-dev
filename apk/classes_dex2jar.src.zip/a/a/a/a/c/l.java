package a.a.a.a.c;

import java.util.Iterator;

public abstract interface l<K> extends Iterator<K>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.l
 * JD-Core Version:    0.6.2
 */