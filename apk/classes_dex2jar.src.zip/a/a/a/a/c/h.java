package a.a.a.a.c;

import a.a.a.a.d;
import java.io.Serializable;

final class h<K>
  implements d<K[]>, Serializable
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.h
 * JD-Core Version:    0.6.2
 */