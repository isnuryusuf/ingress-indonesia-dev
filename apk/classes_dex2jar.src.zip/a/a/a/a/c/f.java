package a.a.a.a.c;

public abstract class f<K> extends e<K>
  implements q<K>
{
  public abstract i<K> b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.f
 * JD-Core Version:    0.6.2
 */