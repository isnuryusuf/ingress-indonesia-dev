package a.a.a.a.c;

import java.util.SortedSet;

public abstract interface q<K> extends p<K>, SortedSet<K>
{
  public abstract i<K> b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.q
 * JD-Core Version:    0.6.2
 */