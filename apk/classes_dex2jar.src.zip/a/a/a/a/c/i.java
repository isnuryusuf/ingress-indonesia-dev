package a.a.a.a.c;

import a.a.a.a.a;

public abstract interface i<K> extends a<K>, l<K>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.c.i
 * JD-Core Version:    0.6.2
 */