package a.a.a.a.b;

final class ba extends o
{
  private ba(ax paramax)
  {
    super(paramax);
  }

  public final ca d()
  {
    return new bd(this.b);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ba
 * JD-Core Version:    0.6.2
 */