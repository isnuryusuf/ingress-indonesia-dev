package a.a.a.a.b;

final class e extends t
{
  e(b paramb)
  {
  }

  public final ce a()
  {
    return new f(this);
  }

  public final boolean a(long paramLong)
  {
    return this.a.b(paramLong);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final int size()
  {
    return this.a.size();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.e
 * JD-Core Version:    0.6.2
 */