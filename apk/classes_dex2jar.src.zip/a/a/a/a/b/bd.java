package a.a.a.a.b;

final class bd extends bc
  implements ci
{
  public bd(ax paramax)
  {
    super(paramax);
  }

  public final long a()
  {
    return e().a;
  }

  public final long b()
  {
    return f().a;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bd
 * JD-Core Version:    0.6.2
 */