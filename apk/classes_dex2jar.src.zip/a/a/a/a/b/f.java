package a.a.a.a.b;

import a.a.a.a.c.l;
import a.a.a.a.c.p;
import java.util.Map.Entry;

final class f extends u
{
  final l<Map.Entry<Long, Long>> a = this.b.a.d().a();

  f(e parame)
  {
  }

  public final long a()
  {
    return ((ae)this.a.next()).b();
  }

  public final boolean hasNext()
  {
    return this.a.hasNext();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.f
 * JD-Core Version:    0.6.2
 */