package a.a.a.a.b;

import a.a.a.a.c.b;
import a.a.a.a.c.l;

final class bm extends b<V>
{
  bm(bl parambl)
  {
  }

  public final l<V> a()
  {
    return new bu(this.a);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean contains(Object paramObject)
  {
    return this.a.containsValue(paramObject);
  }

  public final int size()
  {
    return this.a.i;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bm
 * JD-Core Version:    0.6.2
 */