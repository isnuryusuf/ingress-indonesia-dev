package a.a.a.a.b;

import java.util.Set;

public abstract interface cl extends cb, Set<Long>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.cl
 * JD-Core Version:    0.6.2
 */