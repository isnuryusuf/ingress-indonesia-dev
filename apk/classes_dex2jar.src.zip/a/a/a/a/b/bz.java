package a.a.a.a.b;

import a.a.a.a.d;
import java.io.Serializable;

final class bz
  implements d<long[]>, Serializable
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bz
 * JD-Core Version:    0.6.2
 */