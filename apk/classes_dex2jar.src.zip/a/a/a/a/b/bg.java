package a.a.a.a.b;

import a.a.a.a.c.o;

final class bg extends ap<V>.bf
  implements o<V>
{
  private bg(ap paramap)
  {
    super(paramap);
  }

  public final void add(V paramV)
  {
    throw new UnsupportedOperationException();
  }

  public final V next()
  {
    return e().b;
  }

  public final V previous()
  {
    return f().b;
  }

  public final void set(V paramV)
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bg
 * JD-Core Version:    0.6.2
 */