package a.a.a.a.b;

import a.a.a.a.c.l;
import a.a.a.a.c.p;
import java.util.Map.Entry;

final class d extends u
{
  final l<Map.Entry<Long, Long>> a = this.b.a.d().a();

  d(c paramc)
  {
  }

  public final long a()
  {
    return ((ae)this.a.next()).a();
  }

  public final boolean hasNext()
  {
    return this.a.hasNext();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.d
 * JD-Core Version:    0.6.2
 */