package a.a.a.a.b;

public abstract class z extends s
  implements ci
{
  public void a(long paramLong)
  {
    throw new UnsupportedOperationException();
  }

  public void b(long paramLong)
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.z
 * JD-Core Version:    0.6.2
 */