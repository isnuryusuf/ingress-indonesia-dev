package a.a.a.a.b;

import java.util.SortedSet;

public abstract interface cm extends cl, SortedSet<Long>
{
  public abstract cm a(long paramLong1, long paramLong2);

  public abstract long b();

  public abstract cm b(long paramLong);

  public abstract long c();

  public abstract cm c(long paramLong);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.cm
 * JD-Core Version:    0.6.2
 */