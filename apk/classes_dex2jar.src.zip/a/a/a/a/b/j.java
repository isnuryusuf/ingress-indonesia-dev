package a.a.a.a.b;

import a.a.a.a.c.l;
import a.a.a.a.c.p;
import java.util.Map.Entry;

final class j extends u
{
  final l<Map.Entry<Long, V>> a = this.b.a.c().a();

  j(i parami)
  {
  }

  public final long a()
  {
    return ((bj)this.a.next()).a();
  }

  public final boolean hasNext()
  {
    return this.a.hasNext();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.j
 * JD-Core Version:    0.6.2
 */