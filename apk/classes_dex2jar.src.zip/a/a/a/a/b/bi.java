package a.a.a.a.b;

import a.a.a.a.c.j;
import a.a.a.a.c.p;
import java.util.Map;

public abstract interface bi<V> extends bh<V>, Map<Long, V>
{
  public abstract j<V> b();

  public abstract p<bj<V>> l();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bi
 * JD-Core Version:    0.6.2
 */