package a.a.a.a.b;

import a.a.a.a.d;

public final class by
{
  public static final long[] a = new long[0];
  public static final d b = new bz((byte)0);

  public static long[] a(long[] paramArrayOfLong, int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramArrayOfLong.length)
    {
      long[] arrayOfLong = new long[(int)Math.min(Math.max(106039L * paramArrayOfLong.length >>> 16, paramInt1), 2147483647L)];
      System.arraycopy(paramArrayOfLong, 0, arrayOfLong, 0, paramInt2);
      paramArrayOfLong = arrayOfLong;
    }
    return paramArrayOfLong;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.by
 * JD-Core Version:    0.6.2
 */