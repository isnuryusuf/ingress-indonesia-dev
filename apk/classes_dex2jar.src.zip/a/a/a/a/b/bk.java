package a.a.a.a.b;

import a.a.a.a.c.l;
import a.a.a.a.c.p;

public abstract interface bk<V> extends p<bj<V>>
{
  public abstract l<bj<V>> b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bk
 * JD-Core Version:    0.6.2
 */