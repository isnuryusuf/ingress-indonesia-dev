package a.a.a.a.b;

final class ao extends an
  implements ce
{
  public ao(ag paramag)
  {
    super(paramag, (byte)0);
  }

  public final long a()
  {
    return this.a.c[b()];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ao
 * JD-Core Version:    0.6.2
 */