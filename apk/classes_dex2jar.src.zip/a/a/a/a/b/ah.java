package a.a.a.a.b;

final class ah extends t
{
  ah(ag paramag)
  {
  }

  public final ce a()
  {
    return new ao(this.a);
  }

  public final boolean a(long paramLong)
  {
    return this.a.b(paramLong);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final int size()
  {
    return this.a.i;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ah
 * JD-Core Version:    0.6.2
 */