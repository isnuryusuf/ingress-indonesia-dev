package a.a.a.a.b;

final class aw extends o
{
  private aw(ap paramap)
  {
    super(paramap);
  }

  public final ca d()
  {
    return new av(this.b);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.aw
 * JD-Core Version:    0.6.2
 */