package a.a.a.a.b;

import a.a.a.a.c.j;
import java.util.Map.Entry;

public abstract class n<V> extends h<V>
  implements bv<V>
{
  public final bv<V> a(Long paramLong)
  {
    return f(paramLong.longValue());
  }

  public final bv<V> a(Long paramLong1, Long paramLong2)
  {
    return b(paramLong1.longValue(), paramLong2.longValue());
  }

  public final bv<V> b(Long paramLong)
  {
    return g(paramLong.longValue());
  }

  public j<V> b()
  {
    return new q(this);
  }

  public Long d()
  {
    return Long.valueOf(h());
  }

  public Long e()
  {
    return Long.valueOf(i());
  }

  public cm f()
  {
    return new o(this);
  }

  public final a.a.a.a.c.q<Map.Entry<Long, V>> g()
  {
    return j();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.n
 * JD-Core Version:    0.6.2
 */