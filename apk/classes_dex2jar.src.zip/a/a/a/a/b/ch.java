package a.a.a.a.b;

import java.util.List;

public abstract interface ch extends cb, Comparable<List<? extends Long>>, List<Long>
{
  public abstract void a(int paramInt, long paramLong);

  public abstract long b(int paramInt, long paramLong);

  public abstract ci b();

  public abstract void b(int paramInt1, int paramInt2);

  public abstract long c(int paramInt);

  public abstract long g(int paramInt);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ch
 * JD-Core Version:    0.6.2
 */