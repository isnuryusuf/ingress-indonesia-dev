package a.a.a.a.b;

import java.util.ListIterator;

public abstract interface ci extends ca, ListIterator<Long>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ci
 * JD-Core Version:    0.6.2
 */