package a.a.a.a.b;

import a.a.a.a.c.b;

final class k extends b<V>
{
  k(h paramh)
  {
  }

  public final a.a.a.a.c.l<V> a()
  {
    return new l(this);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean contains(Object paramObject)
  {
    return this.a.containsValue(paramObject);
  }

  public final int size()
  {
    return this.a.size();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.k
 * JD-Core Version:    0.6.2
 */