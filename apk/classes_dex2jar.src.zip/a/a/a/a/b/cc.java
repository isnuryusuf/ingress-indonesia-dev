package a.a.a.a.b;

import java.util.Comparator;

public abstract interface cc extends Comparator<Long>
{
  public abstract int a();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.cc
 * JD-Core Version:    0.6.2
 */