package a.a.a.a.b;

import a.a.a.a.c.l;

final class bu extends bl<V>.bt
  implements l<V>
{
  public bu(bl parambl)
  {
    super(parambl, (byte)0);
  }

  public final V next()
  {
    return this.a.c[b()];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bu
 * JD-Core Version:    0.6.2
 */