package a.a.a.a.b;

import a.a.a.a.c.o;

final class bb extends ap<V>.a.a.a.a.b.ax.a.a.a.a.b.bc
  implements o<bj<V>>
{
  bb(ax paramax)
  {
    super(paramax);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bb
 * JD-Core Version:    0.6.2
 */