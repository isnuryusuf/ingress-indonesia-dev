package a.a.a.a.b;

import a.a.a.a.c.b;
import a.a.a.a.c.l;

public final class q extends b<V>
{
  protected q(n paramn)
  {
  }

  public final l<V> a()
  {
    return new r(this.a.g().b());
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean contains(Object paramObject)
  {
    return this.a.containsValue(paramObject);
  }

  public final int size()
  {
    return this.a.size();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.q
 * JD-Core Version:    0.6.2
 */