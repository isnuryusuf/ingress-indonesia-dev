package a.a.a.a.b;

import a.a.a.a.c.i;

public abstract interface ca extends ce, i<Long>
{
  public abstract long b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ca
 * JD-Core Version:    0.6.2
 */