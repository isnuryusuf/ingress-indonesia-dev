package a.a.a.a.b;

import a.a.a.a.c.q;

public class o extends ab
{
  protected o(n paramn)
  {
  }

  public final cm a(long paramLong1, long paramLong2)
  {
    return this.a.b(paramLong1, paramLong2).f();
  }

  public final boolean a(long paramLong)
  {
    return this.a.b(paramLong);
  }

  public final long b()
  {
    return this.a.h();
  }

  public final cm b(long paramLong)
  {
    return this.a.f(paramLong).f();
  }

  public final long c()
  {
    return this.a.i();
  }

  public final cm c(long paramLong)
  {
    return this.a.g(paramLong).f();
  }

  public void clear()
  {
    this.a.clear();
  }

  public ca d()
  {
    return new p(this.a.g().b());
  }

  public int size()
  {
    return this.a.size();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.o
 * JD-Core Version:    0.6.2
 */