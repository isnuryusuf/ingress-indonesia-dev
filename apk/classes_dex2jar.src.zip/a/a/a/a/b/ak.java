package a.a.a.a.b;

final class ak extends aa
{
  private ak(ag paramag)
  {
  }

  public final ce a()
  {
    return new aj(this.a);
  }

  public final boolean a(long paramLong)
  {
    return this.a.c(paramLong);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean f(long paramLong)
  {
    int i = this.a.i;
    this.a.a(paramLong);
    return this.a.i != i;
  }

  public final int size()
  {
    return this.a.i;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ak
 * JD-Core Version:    0.6.2
 */