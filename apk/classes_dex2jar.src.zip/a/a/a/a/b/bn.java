package a.a.a.a.b;

import a.a.a.a.c.l;

final class bn extends bl<V>.bt
  implements l<bj<V>>
{
  private bl<V>.br b;

  private bn(bl parambl)
  {
    super(parambl, (byte)0);
  }

  public final void remove()
  {
    super.remove();
    br.a(this.b);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bn
 * JD-Core Version:    0.6.2
 */