package a.a.a.a.b;

import a.a.a.a.c.l;

final class bo extends bl<V>.bt
  implements l<bj<V>>
{
  final m<V> a = new m();

  private bo(bl parambl)
  {
    super(parambl, (byte)0);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bo
 * JD-Core Version:    0.6.2
 */