package a.a.a.a.b;

import java.util.Map.Entry;

public abstract interface ae extends Map.Entry<Long, Long>
{
  public abstract long a();

  public abstract long b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ae
 * JD-Core Version:    0.6.2
 */