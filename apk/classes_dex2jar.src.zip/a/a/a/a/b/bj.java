package a.a.a.a.b;

import java.util.Map.Entry;

public abstract interface bj<V> extends Map.Entry<Long, V>
{
  public abstract long a();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bj
 * JD-Core Version:    0.6.2
 */