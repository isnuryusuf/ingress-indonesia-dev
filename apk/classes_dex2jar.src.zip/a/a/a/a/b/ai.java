package a.a.a.a.b;

import a.a.a.a.c.l;

final class ai extends an
  implements l<ae>
{
  private al f;

  private ai(ag paramag)
  {
    super(paramag, (byte)0);
  }

  public final void remove()
  {
    super.remove();
    al.a(this.f);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ai
 * JD-Core Version:    0.6.2
 */