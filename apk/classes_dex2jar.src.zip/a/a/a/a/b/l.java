package a.a.a.a.b;

import a.a.a.a.c.c;
import a.a.a.a.c.p;
import java.util.Map.Entry;

final class l extends c<V>
{
  final a.a.a.a.c.l<Map.Entry<Long, V>> a = this.b.a.c().a();

  l(k paramk)
  {
  }

  public final boolean hasNext()
  {
    return this.a.hasNext();
  }

  public final V next()
  {
    return ((bj)this.a.next()).getValue();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.l
 * JD-Core Version:    0.6.2
 */