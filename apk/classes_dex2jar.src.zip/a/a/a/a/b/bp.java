package a.a.a.a.b;

final class bp extends bt
  implements ce
{
  public bp(bl parambl)
  {
    super(parambl, (byte)0);
  }

  public final long a()
  {
    return this.a.b[b()];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bp
 * JD-Core Version:    0.6.2
 */