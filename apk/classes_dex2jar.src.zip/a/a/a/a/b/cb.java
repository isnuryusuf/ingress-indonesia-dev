package a.a.a.a.b;

import java.util.Collection;

public abstract interface cb extends cd, Collection<Long>
{
  public abstract boolean a(long paramLong);

  public abstract boolean d(long paramLong);

  public abstract long[] e();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.cb
 * JD-Core Version:    0.6.2
 */