package a.a.a.a.b;

import a.a.a.a.b;

public abstract interface bh<V> extends b<Long, V>
{
  public abstract V a(long paramLong);

  public abstract V a(long paramLong, V paramV);

  public abstract boolean b(long paramLong);

  public abstract V e(long paramLong);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bh
 * JD-Core Version:    0.6.2
 */