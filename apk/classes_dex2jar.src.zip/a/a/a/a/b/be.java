package a.a.a.a.b;

import a.a.a.a.c.o;

final class be extends ap<V>.a.a.a.a.b.ax.a.a.a.a.b.bc
  implements o<V>
{
  private be(ax paramax)
  {
    super(paramax);
  }

  public final void add(V paramV)
  {
    throw new UnsupportedOperationException();
  }

  public final V next()
  {
    return e().b;
  }

  public final V previous()
  {
    return f().b;
  }

  public final void set(V paramV)
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.be
 * JD-Core Version:    0.6.2
 */