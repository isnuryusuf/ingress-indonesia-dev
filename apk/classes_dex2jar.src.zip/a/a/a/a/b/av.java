package a.a.a.a.b;

final class av extends bf
  implements ci
{
  public av(ap paramap)
  {
    super(paramap);
  }

  public final long a()
  {
    return e().a;
  }

  public final long b()
  {
    return f().a;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.av
 * JD-Core Version:    0.6.2
 */