package a.a.a.a.b;

import java.io.Serializable;
import java.util.NoSuchElementException;

public final class cg extends z
  implements Serializable, Cloneable
{
  public final long a()
  {
    throw new NoSuchElementException();
  }

  public final long b()
  {
    throw new NoSuchElementException();
  }

  public final Object clone()
  {
    return cf.a;
  }

  public final boolean hasNext()
  {
    return false;
  }

  public final boolean hasPrevious()
  {
    return false;
  }

  public final int nextIndex()
  {
    return 0;
  }

  public final int previousIndex()
  {
    return -1;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.cg
 * JD-Core Version:    0.6.2
 */