package a.a.a.a.b;

import a.a.a.a.b;

public abstract interface ac extends b<Long, Long>
{
  public abstract long a(long paramLong1, long paramLong2);

  public abstract void a();

  public abstract boolean c(long paramLong);

  public abstract long d(long paramLong);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ac
 * JD-Core Version:    0.6.2
 */