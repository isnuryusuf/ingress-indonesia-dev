package a.a.a.a.b;

import java.util.Iterator;

public abstract interface ce extends Iterator<Long>
{
  public abstract long a();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ce
 * JD-Core Version:    0.6.2
 */