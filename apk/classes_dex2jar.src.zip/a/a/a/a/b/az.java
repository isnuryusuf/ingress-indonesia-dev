package a.a.a.a.b;

import a.a.a.a.c.b;
import a.a.a.a.c.l;

final class az extends b<V>
{
  az(ax paramax)
  {
  }

  public final l<V> a()
  {
    return new be(this.a, (byte)0);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean contains(Object paramObject)
  {
    return this.a.containsValue(paramObject);
  }

  public final int size()
  {
    return this.a.size();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.az
 * JD-Core Version:    0.6.2
 */