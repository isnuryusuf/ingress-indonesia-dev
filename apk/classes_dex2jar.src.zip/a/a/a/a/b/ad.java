package a.a.a.a.b;

import a.a.a.a.c.p;
import java.util.Map;

public abstract interface ad extends ac, Map<Long, Long>
{
  public abstract p<ae> e();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.ad
 * JD-Core Version:    0.6.2
 */