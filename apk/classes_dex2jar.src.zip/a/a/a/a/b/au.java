package a.a.a.a.b;

import a.a.a.a.c.o;

final class au extends ap<V>.bf
  implements o<bj<V>>
{
  au(ap paramap)
  {
    super(paramap);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.au
 * JD-Core Version:    0.6.2
 */