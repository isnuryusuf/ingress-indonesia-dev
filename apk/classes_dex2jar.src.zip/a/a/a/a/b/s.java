package a.a.a.a.b;

public abstract class s extends u
  implements ca
{
  public long b()
  {
    return Long.valueOf(b()).longValue();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.s
 * JD-Core Version:    0.6.2
 */