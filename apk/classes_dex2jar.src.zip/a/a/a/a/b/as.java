package a.a.a.a.b;

import a.a.a.a.c.b;
import a.a.a.a.c.l;

final class as extends b<V>
{
  as(ap paramap)
  {
  }

  public final l<V> a()
  {
    return new bg(this.a, (byte)0);
  }

  public final void clear()
  {
    this.a.clear();
  }

  public final boolean contains(Object paramObject)
  {
    return this.a.containsValue(paramObject);
  }

  public final int size()
  {
    return this.a.c;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.as
 * JD-Core Version:    0.6.2
 */