package a.a.a.a.b;

import a.a.a.a.c.p;

public abstract interface af extends p<ae>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.af
 * JD-Core Version:    0.6.2
 */