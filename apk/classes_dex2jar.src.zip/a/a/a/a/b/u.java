package a.a.a.a.b;

public abstract class u
  implements ce
{
  public long a()
  {
    return Long.valueOf(a()).longValue();
  }

  public void remove()
  {
    throw new UnsupportedOperationException();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.u
 * JD-Core Version:    0.6.2
 */