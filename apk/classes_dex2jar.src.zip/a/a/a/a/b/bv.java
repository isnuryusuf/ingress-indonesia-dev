package a.a.a.a.b;

import a.a.a.a.c.j;
import a.a.a.a.c.q;
import java.util.SortedMap;

public abstract interface bv<V> extends bi<V>, SortedMap<Long, V>
{
  public abstract bv<V> b(long paramLong1, long paramLong2);

  public abstract j<V> b();

  public abstract bv<V> f(long paramLong);

  public abstract cm f();

  public abstract bv<V> g(long paramLong);

  public abstract long h();

  public abstract long i();

  public abstract q<bj<V>> j();

  public abstract cc k();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bv
 * JD-Core Version:    0.6.2
 */