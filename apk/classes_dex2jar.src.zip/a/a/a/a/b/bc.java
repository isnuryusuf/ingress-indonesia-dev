package a.a.a.a.b;

class bc extends bf
{
  bc(ax paramax)
  {
    super(paramax.i);
    this.d = paramax.m();
  }

  final void c()
  {
    this.c = this.c.j();
    if ((!this.b.d) && (this.c != null) && (this.b.i.a(this.c.a, this.b.b) < 0))
      this.c = null;
  }

  final void d()
  {
    this.d = this.d.i();
    if ((!this.b.e) && (this.d != null) && (this.b.i.a(this.d.a, this.b.c) >= 0))
      this.d = null;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b.bc
 * JD-Core Version:    0.6.2
 */