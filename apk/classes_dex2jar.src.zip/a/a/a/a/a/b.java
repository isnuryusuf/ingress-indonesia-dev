package a.a.a.a.a;

import a.a.a.a.d;
import java.io.Serializable;

final class b
  implements d<boolean[]>, Serializable
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b
 * JD-Core Version:    0.6.2
 */