package a.a.a.a.a;

import a.a.a.a.d;

public final class a
{
  public static final boolean[] a = new boolean[0];
  public static final d b = new b((byte)0);

  public static void a(boolean[] paramArrayOfBoolean)
  {
    int j;
    for (int i = paramArrayOfBoolean.length; ; i = j)
    {
      j = i - 1;
      if (i == 0)
        break;
      paramArrayOfBoolean[j] = false;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a.a
 * JD-Core Version:    0.6.2
 */