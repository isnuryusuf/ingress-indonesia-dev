package a.a.a.a;

public abstract interface b<K, V>
{
  public abstract void clear();

  public abstract int size();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.b
 * JD-Core Version:    0.6.2
 */