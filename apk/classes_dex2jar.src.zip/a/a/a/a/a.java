package a.a.a.a;

import java.util.Iterator;

public abstract interface a<K> extends Iterator<K>
{
  public abstract K previous();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     a.a.a.a.a
 * JD-Core Version:    0.6.2
 */