package org.codehaus.jackson;

public class JsonGenerationException extends JsonProcessingException
{
  public JsonGenerationException(String paramString)
  {
    super(paramString, null);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.JsonGenerationException
 * JD-Core Version:    0.6.2
 */