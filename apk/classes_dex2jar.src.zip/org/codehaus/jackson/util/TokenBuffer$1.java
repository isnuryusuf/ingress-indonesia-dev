package org.codehaus.jackson.util;

class TokenBuffer$1
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.util.TokenBuffer.1
 * JD-Core Version:    0.6.2
 */