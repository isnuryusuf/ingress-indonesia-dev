package org.codehaus.jackson.node;

public abstract class NumericNode extends ValueNode
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.node.NumericNode
 * JD-Core Version:    0.6.2
 */