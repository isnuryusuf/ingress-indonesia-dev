package org.codehaus.jackson.map;

public abstract interface MapperConfig$ConfigFeature
{
  public abstract boolean enabledByDefault();

  public abstract int getMask();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.MapperConfig.ConfigFeature
 * JD-Core Version:    0.6.2
 */