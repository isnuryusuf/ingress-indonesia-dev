package org.codehaus.jackson.map;

public enum AnnotationIntrospector$ReferenceProperty$Type
{
  static
  {
    BACK_REFERENCE = new Type("BACK_REFERENCE", 1);
    Type[] arrayOfType = new Type[2];
    arrayOfType[0] = MANAGED_REFERENCE;
    arrayOfType[1] = BACK_REFERENCE;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.AnnotationIntrospector.ReferenceProperty.Type
 * JD-Core Version:    0.6.2
 */