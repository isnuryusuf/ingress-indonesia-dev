package org.codehaus.jackson.map;

public abstract class JsonDeserializer$None extends JsonDeserializer<Object>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.JsonDeserializer.None
 * JD-Core Version:    0.6.2
 */