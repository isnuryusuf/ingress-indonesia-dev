package org.codehaus.jackson.map.deser;

class BeanDeserializer$1
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.BeanDeserializer.1
 * JD-Core Version:    0.6.2
 */