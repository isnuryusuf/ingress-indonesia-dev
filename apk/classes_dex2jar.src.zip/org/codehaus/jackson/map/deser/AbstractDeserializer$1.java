package org.codehaus.jackson.map.deser;

class AbstractDeserializer$1
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.deser.AbstractDeserializer.1
 * JD-Core Version:    0.6.2
 */