package org.codehaus.jackson.map.util;

public final class ArrayBuilders$BooleanBuilder extends PrimitiveArrayBuilder<boolean[]>
{
  public final boolean[] _constructArray(int paramInt)
  {
    return new boolean[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.BooleanBuilder
 * JD-Core Version:    0.6.2
 */