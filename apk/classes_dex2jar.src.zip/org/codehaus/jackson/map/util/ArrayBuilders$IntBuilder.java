package org.codehaus.jackson.map.util;

public final class ArrayBuilders$IntBuilder extends PrimitiveArrayBuilder<int[]>
{
  public final int[] _constructArray(int paramInt)
  {
    return new int[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.IntBuilder
 * JD-Core Version:    0.6.2
 */