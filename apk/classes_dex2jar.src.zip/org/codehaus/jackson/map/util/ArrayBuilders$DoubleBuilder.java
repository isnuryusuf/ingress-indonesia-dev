package org.codehaus.jackson.map.util;

public final class ArrayBuilders$DoubleBuilder extends PrimitiveArrayBuilder<double[]>
{
  public final double[] _constructArray(int paramInt)
  {
    return new double[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.DoubleBuilder
 * JD-Core Version:    0.6.2
 */