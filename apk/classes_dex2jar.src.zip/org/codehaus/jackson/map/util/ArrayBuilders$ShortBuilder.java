package org.codehaus.jackson.map.util;

public final class ArrayBuilders$ShortBuilder extends PrimitiveArrayBuilder<short[]>
{
  public final short[] _constructArray(int paramInt)
  {
    return new short[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.ShortBuilder
 * JD-Core Version:    0.6.2
 */