package org.codehaus.jackson.map.util;

public final class ArrayBuilders$FloatBuilder extends PrimitiveArrayBuilder<float[]>
{
  public final float[] _constructArray(int paramInt)
  {
    return new float[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.FloatBuilder
 * JD-Core Version:    0.6.2
 */