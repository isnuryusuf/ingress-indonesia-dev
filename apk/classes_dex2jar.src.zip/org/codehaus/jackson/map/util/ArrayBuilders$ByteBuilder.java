package org.codehaus.jackson.map.util;

public final class ArrayBuilders$ByteBuilder extends PrimitiveArrayBuilder<byte[]>
{
  public final byte[] _constructArray(int paramInt)
  {
    return new byte[paramInt];
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.util.ArrayBuilders.ByteBuilder
 * JD-Core Version:    0.6.2
 */