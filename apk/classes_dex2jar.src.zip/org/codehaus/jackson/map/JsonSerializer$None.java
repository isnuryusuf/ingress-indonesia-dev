package org.codehaus.jackson.map;

public abstract class JsonSerializer$None extends JsonSerializer<Object>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.JsonSerializer.None
 * JD-Core Version:    0.6.2
 */