package org.codehaus.jackson.map;

public abstract class KeyDeserializer$None extends KeyDeserializer
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.KeyDeserializer.None
 * JD-Core Version:    0.6.2
 */