package org.codehaus.jackson.map;

public abstract class KeyDeserializer
{
  public abstract Object deserializeKey(String paramString, DeserializationContext paramDeserializationContext);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     org.codehaus.jackson.map.KeyDeserializer
 * JD-Core Version:    0.6.2
 */