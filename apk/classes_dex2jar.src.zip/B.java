import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class B extends ClickListener
{
  B(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.e);
    for (boolean bool = true; ; bool = false)
    {
      J.e = bool;
      b.a(this.a.a, true);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     B
 * JD-Core Version:    0.6.2
 */