package com.badlogic.gdx.utils;

public abstract interface Disposable
{
  public abstract void dispose();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     com.badlogic.gdx.utils.Disposable
 * JD-Core Version:    0.6.2
 */