package com.badlogic.gdx.scenes.scene2d;

public abstract interface EventListener
{
  public abstract boolean handle(Event paramEvent);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     com.badlogic.gdx.scenes.scene2d.EventListener
 * JD-Core Version:    0.6.2
 */