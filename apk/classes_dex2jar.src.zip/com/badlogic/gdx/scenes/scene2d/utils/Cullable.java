package com.badlogic.gdx.scenes.scene2d.utils;

import com.badlogic.gdx.math.Rectangle;

public abstract interface Cullable
{
  public abstract void setCullingArea(Rectangle paramRectangle);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     com.badlogic.gdx.scenes.scene2d.utils.Cullable
 * JD-Core Version:    0.6.2
 */