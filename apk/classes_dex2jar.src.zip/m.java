import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class m extends ClickListener
{
  m(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.r);
    for (boolean bool = true; ; bool = false)
    {
      J.r = bool;
      b.c(this.a.a);
      com.nianticproject.ingress.common.scanner.visuals.bj.a = J.r;
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     m
 * JD-Core Version:    0.6.2
 */