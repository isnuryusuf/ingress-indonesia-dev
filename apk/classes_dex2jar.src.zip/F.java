import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class F extends ClickListener
{
  F(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.h);
    for (boolean bool = true; ; bool = false)
    {
      J.h = bool;
      b.a(this.a.a, true);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     F
 * JD-Core Version:    0.6.2
 */