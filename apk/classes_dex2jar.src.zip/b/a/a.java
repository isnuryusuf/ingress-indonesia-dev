package b.a;

public abstract interface a<T>
{
  public abstract T a();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     b.a.a
 * JD-Core Version:    0.6.2
 */