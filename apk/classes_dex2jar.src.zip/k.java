import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class k extends ClickListener
{
  k(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.p);
    for (boolean bool = true; ; bool = false)
    {
      J.p = bool;
      b.c(this.a.a);
      J.a();
      b.d(this.a.a).a.setText("Restart is recommended");
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     k
 * JD-Core Version:    0.6.2
 */