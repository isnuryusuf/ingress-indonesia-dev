import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.nianticproject.ingress.common.inventory.i;

final class R extends ClickListener
{
  R(Q paramQ)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (this.a.a == null)
      return;
    J.a.a(this.a.a);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     R
 * JD-Core Version:    0.6.2
 */