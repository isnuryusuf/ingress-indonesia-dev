import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class p extends ClickListener
{
  p(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.u);
    for (boolean bool = true; ; bool = false)
    {
      J.u = bool;
      b.c(this.a.a);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     p
 * JD-Core Version:    0.6.2
 */