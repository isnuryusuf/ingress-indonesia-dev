import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class r extends ClickListener
{
  r(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.v);
    for (boolean bool = true; ; bool = false)
    {
      J.v = bool;
      b.c(this.a.a);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     r
 * JD-Core Version:    0.6.2
 */