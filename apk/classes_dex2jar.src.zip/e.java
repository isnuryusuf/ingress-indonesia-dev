import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class e extends ClickListener
{
  e(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.j);
    for (boolean bool = true; ; bool = false)
    {
      J.j = bool;
      b.b(this.a.a);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     e
 * JD-Core Version:    0.6.2
 */