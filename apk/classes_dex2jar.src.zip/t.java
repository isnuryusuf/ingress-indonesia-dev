import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class t extends ClickListener
{
  t(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    switch (J.b)
    {
    default:
    case 0:
    case 30000:
    case 60000:
    case 120000:
    case 300000:
    case 600000:
    case 900000:
    }
    while (true)
    {
      b.c(this.a.a);
      J.b();
      return;
      J.b = 30000;
      continue;
      J.b = 60000;
      continue;
      J.b = 120000;
      continue;
      J.b = 300000;
      continue;
      J.b = 600000;
      continue;
      J.b = 900000;
      continue;
      J.b = 0;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     t
 * JD-Core Version:    0.6.2
 */