package android.support.v4.view;

abstract interface q
{
  public abstract boolean a(int paramInt);

  public abstract boolean b(int paramInt);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.q
 * JD-Core Version:    0.6.2
 */