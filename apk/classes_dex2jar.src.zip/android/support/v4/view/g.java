package android.support.v4.view;

import android.os.Bundle;
import android.support.v4.view.a.f;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

class g
  implements d
{
  public f a(Object paramObject, View paramView)
  {
    return null;
  }

  public Object a()
  {
    return null;
  }

  public Object a(a parama)
  {
    return null;
  }

  public void a(Object paramObject, View paramView, int paramInt)
  {
  }

  public void a(Object paramObject, View paramView, android.support.v4.view.a.a parama)
  {
  }

  public boolean a(Object paramObject, View paramView, int paramInt, Bundle paramBundle)
  {
    return false;
  }

  public boolean a(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return false;
  }

  public boolean a(Object paramObject, ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return true;
  }

  public void b(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
  }

  public void c(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
  }

  public void d(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.g
 * JD-Core Version:    0.6.2
 */