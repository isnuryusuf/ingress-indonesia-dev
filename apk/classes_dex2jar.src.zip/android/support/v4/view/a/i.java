package android.support.v4.view.a;

import java.util.ArrayList;
import java.util.List;

final class i
  implements m
{
  i(h paramh, f paramf)
  {
  }

  public final boolean a()
  {
    return f.c();
  }

  public final List<Object> b()
  {
    f.d();
    ArrayList localArrayList = new ArrayList();
    int i = null.size();
    for (int j = 0; j < i; j++)
      localArrayList.add(((a)null.get(j)).a());
    return localArrayList;
  }

  public final Object c()
  {
    f.b();
    return null;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.i
 * JD-Core Version:    0.6.2
 */