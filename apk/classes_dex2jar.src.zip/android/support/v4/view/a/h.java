package android.support.v4.view.a;

final class h extends j
{
  public final Object a(f paramf)
  {
    return new l(new i(this, paramf));
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.h
 * JD-Core Version:    0.6.2
 */