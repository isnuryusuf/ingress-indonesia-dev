package android.support.v4.view.a;

abstract interface g
{
  public abstract Object a(f paramf);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.g
 * JD-Core Version:    0.6.2
 */