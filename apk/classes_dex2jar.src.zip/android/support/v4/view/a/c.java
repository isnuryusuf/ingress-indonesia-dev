package android.support.v4.view.a;

abstract interface c
{
  public abstract void a(Object paramObject, int paramInt);

  public abstract void a(Object paramObject, CharSequence paramCharSequence);

  public abstract void a(Object paramObject, boolean paramBoolean);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.c
 * JD-Core Version:    0.6.2
 */