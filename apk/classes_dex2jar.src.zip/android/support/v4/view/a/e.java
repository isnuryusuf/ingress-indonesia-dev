package android.support.v4.view.a;

class e
  implements c
{
  public void a(Object paramObject, int paramInt)
  {
  }

  public void a(Object paramObject, CharSequence paramCharSequence)
  {
  }

  public void a(Object paramObject, boolean paramBoolean)
  {
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.e
 * JD-Core Version:    0.6.2
 */