package android.support.v4.view;

import android.view.View;

abstract interface ao
{
  public abstract int a(View paramView);

  public abstract void a(View paramView, a parama);

  public abstract boolean a(View paramView, int paramInt);

  public abstract void b(View paramView);

  public abstract int c(View paramView);

  public abstract void d(View paramView);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ao
 * JD-Core Version:    0.6.2
 */