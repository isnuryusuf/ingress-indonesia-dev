package android.support.v4.view;

import android.widget.TextView;

final class aa
  implements z
{
  public final void a(TextView paramTextView)
  {
    paramTextView.setSingleLine();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aa
 * JD-Core Version:    0.6.2
 */