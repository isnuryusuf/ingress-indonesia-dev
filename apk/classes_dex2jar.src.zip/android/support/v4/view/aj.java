package android.support.v4.view;

import android.view.View;

class aj
  implements ao
{
  public int a(View paramView)
  {
    return 2;
  }

  long a()
  {
    return 10L;
  }

  public void a(View paramView, a parama)
  {
  }

  public boolean a(View paramView, int paramInt)
  {
    return false;
  }

  public void b(View paramView)
  {
    paramView.postInvalidateDelayed(a());
  }

  public int c(View paramView)
  {
    return 0;
  }

  public void d(View paramView)
  {
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aj
 * JD-Core Version:    0.6.2
 */