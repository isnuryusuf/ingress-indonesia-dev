package android.support.v4.view;

import android.support.v4.b.c;

final class bb
  implements c<ViewPager.SavedState>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.bb
 * JD-Core Version:    0.6.2
 */