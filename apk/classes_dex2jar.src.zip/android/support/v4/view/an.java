package android.support.v4.view;

import android.view.View;

final class an extends am
{
  public final void b(View paramView)
  {
    paramView.postInvalidateOnAnimation();
  }

  public final int c(View paramView)
  {
    return paramView.getImportantForAccessibility();
  }

  public final void d(View paramView)
  {
    paramView.setImportantForAccessibility(1);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.an
 * JD-Core Version:    0.6.2
 */