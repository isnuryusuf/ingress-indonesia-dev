package android.support.v4.view;

final class aw
{
  Object a;
  int b;
  boolean c;
  float d;
  float e;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aw
 * JD-Core Version:    0.6.2
 */