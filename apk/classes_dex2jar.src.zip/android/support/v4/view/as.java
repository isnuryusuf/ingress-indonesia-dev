package android.support.v4.view;

import android.view.ViewConfiguration;

abstract interface as
{
  public abstract int a(ViewConfiguration paramViewConfiguration);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.as
 * JD-Core Version:    0.6.2
 */