package android.support.v4.view;

abstract interface ay
{
  public abstract void a(v paramv1, v paramv2);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ay
 * JD-Core Version:    0.6.2
 */