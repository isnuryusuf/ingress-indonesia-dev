package android.support.v4.view;

import android.view.View;

class ak extends aj
{
  public final int a(View paramView)
  {
    return paramView.getOverScrollMode();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ak
 * JD-Core Version:    0.6.2
 */