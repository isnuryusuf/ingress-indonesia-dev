package android.support.v4.view;

public abstract interface az
{
  public abstract void a(int paramInt);

  public abstract void a(int paramInt, float paramFloat);

  public abstract void b(int paramInt);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.az
 * JD-Core Version:    0.6.2
 */