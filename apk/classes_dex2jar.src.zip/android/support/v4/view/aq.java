package android.support.v4.view;

import android.view.ViewConfiguration;

final class aq
  implements as
{
  public final int a(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.getScaledTouchSlop();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.aq
 * JD-Core Version:    0.6.2
 */