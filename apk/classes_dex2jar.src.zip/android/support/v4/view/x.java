package android.support.v4.view;

import android.view.View;
import android.view.View.OnClickListener;

final class x
  implements View.OnClickListener
{
  x(PagerTabStrip paramPagerTabStrip)
  {
  }

  public final void onClick(View paramView)
  {
    this.a.a.a(1 + this.a.a.b());
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.x
 * JD-Core Version:    0.6.2
 */