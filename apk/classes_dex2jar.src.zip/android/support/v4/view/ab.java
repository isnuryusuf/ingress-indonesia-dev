package android.support.v4.view;

import android.widget.TextView;

final class ab
  implements z
{
  public final void a(TextView paramTextView)
  {
    paramTextView.setTransformationMethod(new ad(paramTextView.getContext()));
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.6.2
 */