package android.support.v4.app;

public final class e extends RuntimeException
{
  public e(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.e
 * JD-Core Version:    0.6.2
 */