package android.support.v4.app;

import android.support.v4.a.d;

public abstract class w
{
  public static void a()
  {
    y.a = true;
  }

  public abstract <D> d<D> a(x<D> paramx);

  public abstract <D> d<D> b(x<D> paramx);

  public boolean b()
  {
    return false;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.w
 * JD-Core Version:    0.6.2
 */