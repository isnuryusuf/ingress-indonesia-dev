package android.support.v4.app;

import android.app.PendingIntent;

public final class ac
{
  public int a;
  public CharSequence b;
  public PendingIntent c;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ac
 * JD-Core Version:    0.6.2
 */