package android.support.v4.app;

import android.support.v4.a.d;

public abstract interface x<D>
{
  public abstract void A_();

  public abstract d<D> a();

  public abstract void a(D paramD);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.x
 * JD-Core Version:    0.6.2
 */