package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class ao extends AndroidRuntimeException
{
  public ao(String paramString)
  {
    super(paramString);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ao
 * JD-Core Version:    0.6.2
 */