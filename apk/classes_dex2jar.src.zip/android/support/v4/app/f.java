package android.support.v4.app;

import android.os.Parcelable.Creator;

final class f
  implements Parcelable.Creator<Fragment.SavedState>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.f
 * JD-Core Version:    0.6.2
 */