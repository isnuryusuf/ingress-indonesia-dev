package android.support.v4.app;

import android.graphics.Bitmap;

public final class ad extends am
{
  Bitmap a;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ad
 * JD-Core Version:    0.6.2
 */