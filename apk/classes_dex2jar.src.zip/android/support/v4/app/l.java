package android.support.v4.app;

final class l
  implements Runnable
{
  l(k paramk)
  {
  }

  public final void run()
  {
    this.a.e();
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.l
 * JD-Core Version:    0.6.2
 */