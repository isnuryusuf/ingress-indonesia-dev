package android.support.v4.app;

import android.app.Notification;

abstract interface ah
{
  public abstract Notification a(af paramaf);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ah
 * JD-Core Version:    0.6.2
 */