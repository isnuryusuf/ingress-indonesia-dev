package android.support.v4.app;

import android.os.Parcelable.Creator;

final class q
  implements Parcelable.Creator<FragmentState>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.q
 * JD-Core Version:    0.6.2
 */