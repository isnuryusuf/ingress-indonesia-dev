package android.support.v4.app;

import java.util.ArrayList;

final class b
{
  b a;
  b b;
  int c;
  Fragment d;
  int e;
  int f;
  int g;
  int h;
  ArrayList<Fragment> i;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.b
 * JD-Core Version:    0.6.2
 */