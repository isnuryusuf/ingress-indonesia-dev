package android.support.v4.app;

public abstract class am
{
  af b;
  CharSequence c;
  CharSequence d;
  boolean e = false;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.am
 * JD-Core Version:    0.6.2
 */