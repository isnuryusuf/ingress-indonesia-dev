package android.support.v4.app;

import android.os.Parcelable.Creator;

final class c
  implements Parcelable.Creator<BackStackState>
{
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.c
 * JD-Core Version:    0.6.2
 */