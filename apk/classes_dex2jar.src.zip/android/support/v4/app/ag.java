package android.support.v4.app;

import java.util.ArrayList;

public final class ag extends am
{
  ArrayList<CharSequence> a = new ArrayList();

  public final ag a(CharSequence paramCharSequence)
  {
    this.c = paramCharSequence;
    return this;
  }

  public final ag b(CharSequence paramCharSequence)
  {
    this.a.add(paramCharSequence);
    return this;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ag
 * JD-Core Version:    0.6.2
 */