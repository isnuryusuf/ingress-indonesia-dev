package android.support.v4.app;

import android.os.Bundle;

public abstract class j
{
  public abstract Fragment.SavedState a(Fragment paramFragment);

  public abstract Fragment a(int paramInt);

  public abstract Fragment a(Bundle paramBundle, String paramString);

  public abstract Fragment a(String paramString);

  public abstract s a();

  public abstract void a(Bundle paramBundle, String paramString, Fragment paramFragment);

  public abstract void b(int paramInt);

  public abstract boolean b();
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.j
 * JD-Core Version:    0.6.2
 */