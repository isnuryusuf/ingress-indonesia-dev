package android.support.v4.app;

final class m
  implements Runnable
{
  m(k paramk, int paramInt)
  {
  }

  public final void run()
  {
    k localk = this.c;
    localk.a(this.a, this.b);
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.6.2
 */