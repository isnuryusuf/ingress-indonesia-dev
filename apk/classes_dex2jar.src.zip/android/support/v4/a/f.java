package android.support.v4.a;

public abstract interface f<D>
{
  public abstract void a(d<D> paramd, D paramD);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.f
 * JD-Core Version:    0.6.2
 */