package android.support.v4.a;

final class l<Data>
{
  final g a;
  final Data[] b;

  l(g paramg, Data[] paramArrayOfData)
  {
    this.a = paramg;
    this.b = paramArrayOfData;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.l
 * JD-Core Version:    0.6.2
 */