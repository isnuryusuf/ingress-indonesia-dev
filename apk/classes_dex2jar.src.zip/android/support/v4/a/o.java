package android.support.v4.a;

import java.util.concurrent.Callable;

abstract class o<Params, Result>
  implements Callable<Result>
{
  Params[] b;
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.a.o
 * JD-Core Version:    0.6.2
 */