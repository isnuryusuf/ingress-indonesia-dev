package android.support.v4.d;

import android.content.Context;
import android.graphics.Canvas;

abstract interface h
{
  public abstract Object a(Context paramContext);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2);

  public abstract boolean a(Object paramObject);

  public abstract boolean a(Object paramObject, float paramFloat);

  public abstract boolean a(Object paramObject, Canvas paramCanvas);

  public abstract void b(Object paramObject);

  public abstract boolean c(Object paramObject);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.d.h
 * JD-Core Version:    0.6.2
 */