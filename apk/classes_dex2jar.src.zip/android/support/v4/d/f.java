package android.support.v4.d;

import android.content.Context;
import android.graphics.Canvas;

final class f
  implements h
{
  public final Object a(Context paramContext)
  {
    return null;
  }

  public final void a(Object paramObject, int paramInt1, int paramInt2)
  {
  }

  public final boolean a(Object paramObject)
  {
    return true;
  }

  public final boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }

  public final boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }

  public final void b(Object paramObject)
  {
  }

  public final boolean c(Object paramObject)
  {
    return false;
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.d.f
 * JD-Core Version:    0.6.2
 */