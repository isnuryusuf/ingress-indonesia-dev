package android.support.v4.d;

import android.database.Cursor;

abstract interface d
{
  public abstract Cursor a();

  public abstract Cursor a(CharSequence paramCharSequence);

  public abstract void a(Cursor paramCursor);

  public abstract CharSequence b(Cursor paramCursor);
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     android.support.v4.d.d
 * JD-Core Version:    0.6.2
 */