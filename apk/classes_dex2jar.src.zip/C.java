import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

final class C extends ClickListener
{
  C(c paramc)
  {
  }

  public final void clicked(InputEvent paramInputEvent, float paramFloat1, float paramFloat2)
  {
    if (!J.d);
    for (boolean bool = true; ; bool = false)
    {
      J.d = bool;
      b.a(this.a.a, true);
      return;
    }
  }
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     C
 * JD-Core Version:    0.6.2
 */