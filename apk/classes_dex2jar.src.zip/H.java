public final class H
{
  public static final String[] a = { "data", "data-hvga", "data-qvga", "data-xhdpi", "data-xxhdpi" };
}

/* Location:           classes_dex2jar.jar
 * Qualified Name:     H
 * JD-Core Version:    0.6.2
 */